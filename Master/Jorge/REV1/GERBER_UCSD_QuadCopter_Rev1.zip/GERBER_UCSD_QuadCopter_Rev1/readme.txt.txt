>Info
Board Name: UCSD QuadCopter
Part Number: 0
Number of Layers: 2
Dimension X= 3.930 inch
Dimension Y= 3.934 inch
Board Material Type: FR-4
Solder Mask Color: Green
Silkscreen Color: White
Finish Plating: HASAL
Revision Number: 1